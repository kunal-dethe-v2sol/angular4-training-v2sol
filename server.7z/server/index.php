<?php

require_once 'header.php';

$result = array(
    'status' => 200,
    'message' => 'OK'
);

try {
    if($_SERVER['REQUEST_METHOD'] === 'GET') {
        if(isset($_GET['id'])) {
            if($id = (int) $_GET['id']) {
                $groups = json_decode(file_get_contents('data.json'), true);
                if(!empty($groups)) {
                    $key = array_search($id, array_column($groups, 'uuid'));
                    if(!is_null($key)) {
                        $result['status'] = 200;
                        $result['message'] = 'OK';
                        $result['group'] = $groups[$key];
                    } else {
                        $result['status'] = 404;
                        $result['message'] = 'Not Found 0';
                    }
                } else {
                    $result['status'] = 404;
                    $result['message'] = 'Not Found 1';
                }
            } else {
                $result['status'] = 400;
                $result['message'] = 'Bad Request';
            }
        } else {
            $result['status'] = 200;
            $result['message'] = 'OK';
            $groups = json_decode(file_get_contents('data.json'));
            $result['groups'] = $groups;
        }
    } elseif($_SERVER['REQUEST_METHOD'] === 'POST') {
        $fields = array(
            'uuid' => '',
            'name' => '',
        );
        
        foreach($fields as $field=>$value) {
            $fields[$field] = !empty($requestData->$field) ? trim($requestData->$field) : '';
        }
        
        $groups = json_decode(file_get_contents('data.json'));
        $fields['uuid'] = count($groups) + 1;
        $groups[] = (array) $fields;
        file_put_contents('data.json', json_encode($groups));
        
        $result['status'] = 200;
        $result['message'] = 'OK';
        $result['group'] = (array) $fields;
    } elseif($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
        
    } else {
        $result['status'] = 403;
        $result['message'] = 'Unauthorised';
    }
} catch (Exception $ex) {
    $result['status'] = 500;
    $result['message'] = 'Some error occured';
}

http_response_code($result['status']);
echo json_encode($result);
exit();
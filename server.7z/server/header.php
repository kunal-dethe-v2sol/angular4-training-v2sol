<?php

require_once 'helper.php';

$requestData = getRequestData();